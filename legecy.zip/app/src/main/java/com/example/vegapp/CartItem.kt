package com.example.vegapp

class CartItem ( ProductName: String, Price: Int, Quantity: Int, id: String, images : String){

    public val ProductName = ProductName
    public val  Price = Price
    public val Quantity = Quantity
    public val ID = id
    public val images = images
}