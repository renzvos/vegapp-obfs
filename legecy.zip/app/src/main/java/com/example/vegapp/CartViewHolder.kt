package com.example.vegapp

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class CartViewHolder(var TitleBarColor: Int, var Title: String) {

}