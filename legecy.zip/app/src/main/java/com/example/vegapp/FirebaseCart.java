package com.example.vegapp;

import java.util.ArrayList;

public class FirebaseCart {
    public ArrayList<FirebaseCartItem> items;

    public FirebaseCart(){

    }

}

