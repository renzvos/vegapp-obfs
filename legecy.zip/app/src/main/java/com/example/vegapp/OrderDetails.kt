package com.renzvos.ecommerceorderslist

import android.telephony.mbms.StreamingServiceInfo

data class OrderDetails(val orderid : String ,
                        val backgroudColor : String,
                        val subheading  : String,
                        val timeframe : String, val Status: String)

