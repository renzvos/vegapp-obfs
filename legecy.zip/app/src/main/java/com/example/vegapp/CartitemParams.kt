package com.renzvos.ecommerceorderview

class CartitemParams(
    var ProductName: String,
    var Price: String,
    var Quantity: String,
    var id: String,
    var iconurl: String,
    var closebuttoncolor : String
)