package com.example.vegapp

data class ErrorObject(  val gateway : String ,
                         val  gatewayErrorCode : String ,
                         val descripton : String)

