package com.example.vegapp;

import java.util.ArrayList;

public class FirebaseProductReciever {
    public int availible_qty;
    public String description;
    public ArrayList<String> imaages;
    public String pname;
    public String unit;




    public FirebaseProductReciever()
    {}


}
