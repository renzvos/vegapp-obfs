package com.example.vegapp

class CartStaticLP (titlebarColor : Int , Title :String ) {
    var titlebarColor = titlebarColor
    var Title = Title
    var leftbutton = false


    public fun setLeftButton()
    {
        leftbutton = true
    }


}